package com.chocklatecake.cakerecipe;

public class Recipe {
    private final String title;
    private final String description;
    private final int imageRes; // Add this field

    // Updated constructor with image resource
    public Recipe(String title, String description, int imageRes) {
        this.title = title;
        this.description = description;
        this.imageRes = imageRes;
    }

    // Add getter for image resource
    public int getImageRes() {
        return imageRes;
    }

    // Keep existing getters
    public String getTitle() { return title; }
    public String getDescription() { return description; }
}