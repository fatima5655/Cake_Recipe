package com.chocklatecake.cakerecipe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BlackForestActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_black_forest);
    }
}