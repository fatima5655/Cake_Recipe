// GalleryItem.java
package com.chocklatecake.cakerecipe;

public class GalleryItem {
    private final int imageRes;    // Image resource ID
    private final String cakeName; // Text to display

    // Constructor to initialize values
    public GalleryItem(int imageRes, String cakeName) {
        this.imageRes = imageRes;
        this.cakeName = cakeName;
    }

    // Getter methods
    public int getImageRes() {
        return imageRes;
    }

    public String getCakeName() {
        return cakeName;
    }
}