package com.chocklatecake.cakerecipe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private ViewPager2 imageSlider;
    private Handler autoSlideHandler = new Handler();
    private Runnable autoSlideRunnable;
    private static final long SLIDE_INTERVAL = 5000; // 5 seconds
    private int currentPage = 0;
    private List<Integer> imageResources;

    public HomeFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        setupImageSlider(view);
        setupRecipeList(view);
        setupGallery(view);

        return view;
    }

    private void setupImageSlider(View view) {
        imageSlider = view.findViewById(R.id.imageSlider);
        imageResources = getSampleImages();
        ImageSliderAdapter sliderAdapter = new ImageSliderAdapter(imageResources);
        imageSlider.setAdapter(sliderAdapter);
        imageSlider.setOffscreenPageLimit(1);

        // Start from first item
        imageSlider.setCurrentItem(0, false);
        setupAutoScroll();
    }

    private void setupRecipeList(View view) {
        RecyclerView recipeRecyclerView = view.findViewById(R.id.recipeRecyclerView);
        recipeRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recipeRecyclerView.setAdapter(new RecipeAdapter(getSampleRecipes()));
    }

    private void setupGallery(View view) {
        RecyclerView galleryRecyclerView = view.findViewById(R.id.galleryRecyclerView);
        galleryRecyclerView.setLayoutManager(
                new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        galleryRecyclerView.setAdapter(new GalleryAdapter(getSampleGallery(), position -> {
            Intent intent;
            switch(position) {
                case 0: // Chocolate Cake
                    intent = new Intent(getActivity(), ChocolateCakeActivity.class);
                    break;
                case 1: // Red Velvet
                    intent = new Intent(getActivity(), RedVelvetActivity.class);
                    break;
                case 2: // Cheesecake
                    intent = new Intent(getActivity(), CheesecakeActivity.class);
                    break;
                case 3: // Black Forest
                    intent = new Intent(getActivity(), BlackForestActivity.class);
                    break;
                default:
                    return;
            }
            startActivity(intent);
        }));
    }

    // Sample Data Methods
    private List<Integer> getSampleImages() {
        List<Integer> images = new ArrayList<>();
        images.add(R.drawable.cake1);
        images.add(R.drawable.cake2);
        images.add(R.drawable.cake3);
        return images;
    }

    private List<Recipe> getSampleRecipes() {
        List<Recipe> recipes = new ArrayList<>();
        recipes.add(new Recipe("Chocolate Cake", "Rich chocolate layers with ganache", R.drawable.cake1));
        return recipes;
    }

    private List<GalleryItem> getSampleGallery() {
        List<GalleryItem> gallery = new ArrayList<>();
        gallery.add(new GalleryItem(R.drawable.chock, "Chocolate Cake"));
        gallery.add(new GalleryItem(R.drawable.staw, "Red Velvet"));
        gallery.add(new GalleryItem(R.drawable.chees, "Cheesecake"));
        gallery.add(new GalleryItem(R.drawable.blackb, "Black Forest"));
        return gallery;
    }

    // Auto-Scroll Logic
    private void setupAutoScroll() {
        autoSlideRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentPage < imageResources.size()) {
                    imageSlider.setCurrentItem(currentPage, true);
                    currentPage++;
                    autoSlideHandler.postDelayed(this, SLIDE_INTERVAL);
                } else {
                    // Stop after showing all items
                    autoSlideHandler.removeCallbacks(this);
                }
            }
        };

        // Start auto-scroll
        autoSlideHandler.postDelayed(autoSlideRunnable, SLIDE_INTERVAL);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (currentPage < imageResources.size()) {
            autoSlideHandler.postDelayed(autoSlideRunnable, SLIDE_INTERVAL);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        autoSlideHandler.removeCallbacks(autoSlideRunnable);
        currentPage = 0; // Reset counter
    }

    // ImageSliderAdapter Class
    private static class ImageSliderAdapter extends RecyclerView.Adapter<ImageSliderAdapter.SliderViewHolder> {
        private final List<Integer> imageResources;

        public ImageSliderAdapter(List<Integer> imageResources) {
            this.imageResources = imageResources;
        }

        @NonNull
        @Override
        public SliderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_slider_image, parent, false);
            return new SliderViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull SliderViewHolder holder, int position) {
            holder.imageView.setImageResource(imageResources.get(position));
        }

        @Override
        public int getItemCount() {
            return imageResources.size();
        }

        static class SliderViewHolder extends RecyclerView.ViewHolder {
            ImageView imageView;

            SliderViewHolder(View itemView) {
                super(itemView);
                imageView = itemView.findViewById(R.id.slider_image);
            }
        }
    }
}