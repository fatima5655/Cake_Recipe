package com.chocklatecake.cakerecipe;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.google.android.material.button.MaterialButton;

public class AboutFragment extends Fragment {

    private MaterialButton btnPrivacy, btnRate, btnContact, btnAbout;

    public AboutFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_about, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize views
        btnPrivacy = view.findViewById(R.id.btn_privacy_policy);
        btnRate = view.findViewById(R.id.btn_rate_us);
        btnContact = view.findViewById(R.id.btn_contact_us);
        btnAbout = view.findViewById(R.id.btn_about_us);

        // Set click listeners
        btnPrivacy.setOnClickListener(v -> openPrivacyPolicy());
        btnRate.setOnClickListener(v -> rateApp());
        btnContact.setOnClickListener(v -> contactUs());
        btnAbout.setOnClickListener(v -> showAboutDetails());

        // Setup toolbar navigation
        view.findViewById(R.id.toolbar).setOnClickListener(v -> requireActivity().onBackPressed());
    }

    private void openPrivacyPolicy() {
        // Open privacy policy in browser
        String url = "https://www.yourwebsite.com/privacy-policy";
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    private void rateApp() {
        try {
            // Try opening Play Store
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("market://details?id=" + requireContext().getPackageName())));
        } catch (ActivityNotFoundException e) {
            // Fallback to browser
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/apps/details?id=" + requireContext().getPackageName())));
        }
    }

    private void contactUs() {
        // Open email client
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"support@cakerecipe.com"});
        intent.putExtra(Intent.EXTRA_SUBJECT, "App Feedback");
        if (intent.resolveActivity(requireActivity().getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private void showAboutDetails() {
        // Show additional about information
        new AboutDialogFragment().show(
                requireActivity().getSupportFragmentManager(),
                "about_dialog"
        );
    }
}