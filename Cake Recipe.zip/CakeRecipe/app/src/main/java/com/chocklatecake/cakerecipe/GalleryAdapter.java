package com.chocklatecake.cakerecipe;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class GalleryAdapter extends RecyclerView.Adapter<GalleryAdapter.ViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    private final List<GalleryItem> galleryItems;
    private final OnItemClickListener listener;

    public GalleryAdapter(List<GalleryItem> galleryItems, OnItemClickListener listener) {
        this.galleryItems = galleryItems;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_gallery, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        GalleryItem item = galleryItems.get(position);
        holder.galleryImage.setImageResource(item.getImageRes());
        holder.cakeNameLabel.setText(item.getCakeName());

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return galleryItems.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView galleryImage;
        TextView cakeNameLabel;

        ViewHolder(View itemView) {
            super(itemView);
            galleryImage = itemView.findViewById(R.id.gallery_image);
            cakeNameLabel = itemView.findViewById(R.id.cake_name_label);
        }
    }
}