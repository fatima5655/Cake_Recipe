package com.chocklatecake.cakerecipe;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import com.airbnb.lottie.LottieAnimationView;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        LottieAnimationView animationView = findViewById(R.id.animationView);

        // Optional: Control animation playback
        animationView.playAnimation();

        // Navigate to main activity after animation
        new Handler().postDelayed(() -> {
            startActivity(new Intent(SplashActivity.this, MainActivity.class));
            finish();
        }, 5000); // 3 seconds duration
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        findViewById(R.id.animationView).clearAnimation();
    }
}